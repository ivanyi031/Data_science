from random import sample
import numpy as np
import matplotlib.pyplot as plt
import math

def transition_matrix(n):
    P = []
    # TODO_D1
    if n %2==0:
        k=int(n/2-1)
    else:
        k=int(math.floor(n/2))
    print(type(k))
    if n==2:
        P.append([0.4,0.6],[0.5,0.5])
    else:
        P=np.zeros((n,n))
        P[0:2,0]=0.4
        
        P[np.arange(k+1),np.arange(k+1)+1]=0.6
        P[2:k+1,0]=0.05
        P[np.arange(2,k+1),np.arange(1,k)]=0.35
        P[k+1:n,0]=0.1
        P[np.arange(k+1,n),np.arange(k,n-1)]=0.4
        P[np.arange(k+1,n-1),np.arange(k+2,n)]=0.5
        P[-1,-1]=0.5

    return P

def propagate(x0, P, k):
    xk = None
    xk=np.matmul(x0,np.linalg.matrix_power(P,k))
    # TODO_D2
    return xk

def create_sample(s0, P, k):
    trajectories = []
    # TODO_D6
    trajectories.append(s0)
    stage=len(P[0])
    for i in range(0,k):
        num=np.random.randint(1,101)
        if s0==0:
            if num <=40:
                s0=0
                trajectories.append(s0)
            else:
                s0=1
                trajectories.append(s0)
        elif s0==stage-1:
            if num<=10:
                s0=0
                trajectories.append(s0)
            elif 10<num<=50:
                s0-=1
                trajectories.append(s0)
            else:
                trajectories.append(s0)
        elif s0<(stage/2):
            if num<=5:
                s0=0
                trajectories.append(s0)
            elif 5<num<=40:
                s0-=1
                trajectories.append(s0)
            else:
                s0+=1
                trajectories.append(s0)
        elif s0>=(stage/2):
            if num<=10:
                s0=0
                trajectories.append(s0)
            elif 10<num<=50:
                s0-=1
                trajectories.append(s0)
            else:
                s0+=1
                trajectories.append(s0)
    return trajectories

def plot_distribution(x):
    plt.plot(x)
    plt.xticks(np.arange(0, len(x), step=1))
    plt.ylim(0, max(x)+0.1)
    plt.xlabel('State (i)')
    plt.ylabel('Probability')
    plt.title('Probability Distribution')
    plt.savefig('Lab04_D3.png', dpi=150)
    plt.show()

def plot_histogram(x):
    plt.hist(x, bins=max(x)+1, range=(-0.5, max(x)+0.5))
    plt.xticks(np.arange(0, max(x)+1, step=1))
    plt.xlabel('State (i)')
    plt.ylabel('Number of smaple')
    plt.title('State Histogram')
    plt.savefig('Lab04_D7.png', dpi=150)
    plt.show()
    
def main():
    
    P = transition_matrix(n=10)
    print(P)
    # TODO_D3
    x0=np.zeros(len(P[0]))
    x0[0]=1
    x8=propagate(x0,P,k=8)
    print(x8)
    plot_distribution(x8)
    #D4
    i=1
    while(True):
        x=propagate(x0,P,i)
        if x[-1]>=0.01:
            break
        i+=1
    print("step:",i)
    #D5
    x0=np.zeros(len(P[0]))
    x0[0]=1
    x50=propagate(x0,P,k=50)
    x_random=np.random.randint(10,size=10)
    x_random=x_random/x_random.sum()
    x_random50=propagate(x_random,P,k=50)
    print("x50:",x50)
    print("x_random50:",x_random50)
    #D7
    last_step=[]
    for i in range(0,1000):
        sample=create_sample(s0=0,P=P,k=8)
        last_step.append(sample[-1])
    plot_histogram(last_step)


if __name__ == "__main__":
    main()