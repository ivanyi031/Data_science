import numpy as np
from random import randrange


A = np.linspace(5,-5,201)

B = np.logspace(0,1,101)

C = np.transpose(np.arange(1,101).reshape(10,10))

d1=np.arange(1,13)
d2=d1*2
d3=d1*3
d4=d1*4
d5=d1*5
d6=d1*6
D6=np.array([d1,d2,d3,d4,d5,d6])
D7=D6+np.array([d6,d6,d6,d6,d6,d6])
D = np.concatenate([D6,D7])

def E(X):
    return X[::2,::2]

def F(X):
    return X[1:-1,1:-1]

def G(X):
    # The shape of return value will be (M, 2)
    up_index=np.zeros((len(X)-1,1))
    dw_index=np.zeros((len(X)-1,1))
    for i in range(0,len(X)):
        if i==0 or i==len(X)-1:
            if i==0:
                dw_index[0]=X[1,0]
            else:
                up_index[-1]=X[-2,len(X)-1]
        else:
            up_index[i-1]=X[i-1,i]
            dw_index[i]=X[i+1,i]
    
    return np.concatenate([dw_index,up_index],axis=1)


# Do NOT modifiy the main function
def main():
    print('A: \n', A, '\n')
    print('B: \n', B, '\n')
    print('C: \n', C, '\n')
    print('D: \n', D, '\n')

    M = randrange(3, 8)
    print(M)
    X = np.random.randint(10, size=(5, 5))

    print('X: \n', X, '\n')
    print('E: \n', E(X), '\n')
    print('F: \n', F(X), '\n')
    print('G: \n', G(X), '\n')


if __name__ == "__main__":
    main()