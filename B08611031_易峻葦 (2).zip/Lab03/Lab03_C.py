import numpy as np

def swap_rows(x, r1, r2):
    # no return values needed
    # no loops allowed
    # do not declare new variables, manipulate x directly
    x[[r1, r2]] = x[[r2, r1]]
def most_value(x):
    # no loops allowed
    counts = np.bincount(x)
    return np.argmax(counts)

def top_n(x, n):
    tops = []
    # no loops allowed
    sorted_index_array = np.argsort(x)
    sorted_array=x[sorted_index_array]
    tops=sorted_array[-n:]
    return tops
    
def pythagorean(x):
    ans=[]
    if len(x[0])!=2:
        raise Exception('input array has to be two columns !!')
    for i in range(0,len(x)):
        other_sides=x[i]
        hypotenuse=(other_sides[0]**2+other_sides[1]**2)**0.5
        ans.append(hypotenuse)

    return ans

def replace_me(v, a, b, c):
    new_array=v.copy()
    if c==None:
        if b==None:
            replace_value=np.array([0,0])
        else:
            replace_value=np.array([b,b])
    else:
        replace_value=np.array([b,c])
    replace_index=np.where(v==a)[0]
    for i in range(0,len(replace_index)):
        new_array=np.insert(new_array,replace_index[i],replace_value)
        replace_index=replace_index+2
    new_array=np.delete(new_array,np.where(new_array==a))

    return new_array


# You may test your function here
def main():

    # Lab04_C1 Swap rows
    print('Lab04_C1 Swap rows:')
    x1 = np.arange(9).reshape(3, 3)
    print(x1)
    swap_rows(x1, 0, 1)
    print(x1, '\n')

    # Lab04_C2 Find most frequent value
    print('Lab04_C2 Find most frequent value:')
    x2 = np.array([1, 2, 2, 1, 3, 2, 4, 1, 2])
    print('The most frequent value is: ', most_value(x2), '\n')

    # Lab04_C3 top n
    print('Lab04_C3 Top n:')
    x3 = np.array([1, 0, 3, 5, 7, 3, 2, 8, 9, 2, 8])
    print('The 3 largest values are: ', top_n(x3, n=3), '\n')

    # Lab04_C4 pythagorean
    print('Lab04_C4 pythagorean:')
    x4 = np.array([[3, 4], [5, 12]])
    print(pythagorean(x4))

    try:
        pythagorean(np.array([12]))
        print('If you see this line, you may not check the input array', '\n')
    except:
        print('\n')

    # Lab04_C5 replace_me
    print('Lab04_C5 replace_me:')
    x5 = np.array([1, 2, 3])
    #x5 = np.array([1,2,3,2,3,9,4,8,7,0,5,2,6,2])
    print(replace_me(x5, 2, 4, 5), '\n')


if __name__ == "__main__":
    main()