import numpy as np
def find_reverse_pair(word_list):
    reverse_pair_list=[]
    pointer=0
    reverse_index=np.zeros((1,len(word_list)))
    while(pointer!=len(word_list)-1):
        for i in range(1,len(word_list)-pointer):
            if reverse_index[0][pointer].any():
                continue
            if reverse_index[0][pointer+i].any():
                continue
            if word_list[pointer][len(word_list[pointer])::-1]==word_list[pointer+i]:
                reverse_pair_list.append((word_list[pointer],word_list[pointer+i]))
                reverse_index[0][pointer+i]=reverse_index[0][pointer]=1
        pointer+=1
    return reverse_pair_list

            



# a=find_reverse_pair(["rat","dgki","bad","tar","dab","fuqh","owio","woow"])
# print(a)