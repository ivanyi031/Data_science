
def draw_grid(m,n):
    a='+ - - '
    b='/     '
    row=a*(n)+'+\n'
    col=(b*(n)+'/\n\n'+b*(n)+'/\n')
    print((row+col)*m+row)
    return
rows=int(input('numbers of rows'))
cols=int(input('numbers of columns'))
draw_grid(rows,cols)
print('finish')