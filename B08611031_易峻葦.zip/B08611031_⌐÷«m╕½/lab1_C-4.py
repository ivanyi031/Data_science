def reverse_lookup(d,v):
    k=[]
    for key, value in d.items():
        if value==v:
            print(key)
            k.append(key)
    return k
my_dict={"color":"red","width":17,"height":19, "length":17}
#print(reverse_lookup(my_dict,17))