import math

def factorial(k):
    if k==0:
        return 1
    sum=1
    for i in range(1,k+1):
        sum*=i
    return sum
def estimate_pi():
    #last_term=2*(2**0.5)/9801*(factorial(0)*(1103+26390*0))/(factorial(0)**4*396**(4*0))
    k=0
    sum=0
    while(True):
        last_term=2*(2**0.5)/9801*(factorial(4*k)*(1103+26390*k))/(factorial(k)**4*396**(4*k))
        if last_term<1e-15:
            break
        sum+=last_term
        k+=1
    return(sum**(-1))
pi=estimate_pi()
# print(pi)
# print(math.pi-pi) 


