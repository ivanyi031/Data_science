import numpy as np
import matplotlib.pyplot as plt
import skimage
from skimage import io


# Do NOT modifify the function names

def my_resize(img, height, width):
    
    # TODO_C1

    return


def my_rotation(img, angle):
    
    # TODO_C2

    return


# You are incouraged to test your program in the main function

def main():
    pass


if __name__ == "__main__":
    main()


