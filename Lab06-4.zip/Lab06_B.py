import numpy as np
import matplotlib.pyplot as plt
import skimage
from skimage import io


# Do NOT modifify the function names

def fade_gradually(img):
    processed = img.copy()

    # TODO_B1

    return processed


def image_matting(img):
    processed = img.copy()

    # TODO_B2

    return processed




# You are incouraged to test your program in the main function

def main():
    pass


if __name__ == "__main__":
    main()


